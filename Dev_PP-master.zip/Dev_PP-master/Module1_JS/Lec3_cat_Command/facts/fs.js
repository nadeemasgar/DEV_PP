let fs = require("fs");

console.log(fs.readFileSync("./f1.txt" , "utf-8"));