//Q create a polyfill of reduce

