// Q) How to implement setInterval of your own using setTimeout


function mySetInterval(cb , time){

    // ???? 




    return {working : true};
}




let interval = mySetInterval(function(){
    console.log("I am in my set timeout !!!")
} , 100);