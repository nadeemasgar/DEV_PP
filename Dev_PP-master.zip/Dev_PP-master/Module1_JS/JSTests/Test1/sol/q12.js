let obj = {"concept":""};


console.log(
  
    JSON.parse( JSON.stringify(obj).slice(0, 12) + "JSON" + JSON.stringify(obj).slice(12) ).concept

  );

  //"{"concept":""}"
  // {"concept":"JSON"}"
  // {"concept":"JSON"}
  // JSON
  