const num = 5;
console.log(num+5);
let a = 6;
a = a+num;
console.log(num-a);