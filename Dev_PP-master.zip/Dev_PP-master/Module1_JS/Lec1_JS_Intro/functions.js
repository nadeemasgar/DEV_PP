// function body // function statement

// let sayHi = function(){
//     console.log("I a m function stored in sayHi !!");
// }


function sayHi(name){
    console.log( name + " says Hiii !!!");
    return 10;
}

// functions are variables 

// function call
// sayHi();

// let value = sayHi();
// console.log( value );
// console.log(sayHi);

let value = sayHi("Steve");
console.log(value);