let name = "TONY STARK";
console.log(name.split(""));
