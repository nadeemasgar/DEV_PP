
* pure functions
* mutations and side effects
* higher order functions 
* map filter and reduce
* polyfill
* closure
* event loop and async architecture
* setTimeout and setInterval
* callbacks

#  references
* https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/#functional-programming
* https://www.youtube.com/watch?v=8zKuNo4ay8E
* https://github.com/getify/You-Dont-Know-JS/tree/1st-ed/async%20%26%20performance -> first 2 chapters