// let obj ={
//     "name":"Steve",
//     "place":"Queens",
//     "skills":"fighting skills"
// }

// let idx=0;
// for(key in obj){
//     idx++;
//     if(idx == 1){
        
//     }
// }

let input = process.argv.slice(2)[0];
console.log(input);