let a = "steve";
let b = "tony";
let c = "natasha";


function printMe(){
    console.log(a , b , c);
}


// module.exports.wintersoldier = a;
// module.exports.ironman = b;
// module.exports.blackwidow = c;

module.exports.callMe = printMe;
