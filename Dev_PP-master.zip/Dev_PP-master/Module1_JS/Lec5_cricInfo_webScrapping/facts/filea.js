let {callMe} = require("./fileb");

callMe();