// cout << "";
// System.out.println("");
// node js not installed => cannot run .js files
// JS file => V8 engine

// top to down
// left to right

console.log("hello world !");
