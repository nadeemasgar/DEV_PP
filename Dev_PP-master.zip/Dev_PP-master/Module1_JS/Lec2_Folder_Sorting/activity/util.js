module.exports = {
    "Images": [".png" , ".jpg" , ".jpeg" , ".gif" ],
    "Audio":  [".mp3"] ,
    "Documents":[".pdf" , ".txt" , ".doc" ] ,
    "Compressed":[".zip"] ,
    "Videos":[".mkv"]
}
