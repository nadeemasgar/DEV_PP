let name = "STEVE";


//module.exports = {}
// module.exports = "STEVE";
// module.exports = name;

module.exports.name = name;
module.exports.movie = "The winter soldier";