// object destructuring
let {  name , movie  } = require("./b.js");

console.log(name);
console.log(movie);



