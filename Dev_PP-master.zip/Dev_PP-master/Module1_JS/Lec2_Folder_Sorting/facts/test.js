let path = require("path");


let ext = path.extname("test");
console.log(ext.length);