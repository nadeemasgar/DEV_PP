// var
// console.log(a);
// var a = 10;
// console.log(a);

// function sayHi(){
//     console.log(b);
//     var b = 20;
//     console.log(b);
//     console.log("function says Hiii !!!");
// }
// sayHi();



// let vs var
let a = 10;
console.log(a);

function sayHi(){
    let b = 20;
    console.log(b);
    console.log("function says Hiii !!!");
}
sayHi();
