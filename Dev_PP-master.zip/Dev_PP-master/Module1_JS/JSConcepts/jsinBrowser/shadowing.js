// console.log(a);
// var a = 10;
// console.log(a);
// var a = 20;
// console.log(a);

// console.log(a);
// let a = 10;
// console.log(a);
// let a = 20;
// console.log(a);

let a = 10;
function callMe(){
    var a = 20;
    console.log(a);
}
callMe();
console.log(a);


