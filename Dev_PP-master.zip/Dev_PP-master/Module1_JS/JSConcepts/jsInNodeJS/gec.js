// var a = 10;

// function sayHi(){
//     var b = 20;
//     console.log(b);
//     console.log("function says Hiii !!!");
// }

// sayHi();

// console.log(a);


// let (ES5) vs var

let a = 10;
console.log(a);

function sayHi(){
    let b = 20;
    console.log(b);
    console.log("function says Hiii !!!");
}
sayHi();
console.log("End");