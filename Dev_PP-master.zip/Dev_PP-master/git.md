# First Time
* git config --global user.name  "sushant"
* git config --global user.email "sushant.beriwal@pepcoding.com"

# If new git repository
* git init
* git remote add origin "path of git repository on github"

# Always steps For Git
* git add . ( Stage all files )
* git commit -m "This is my first commit"
* git push -u origin master

